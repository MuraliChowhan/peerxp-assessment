from django.shortcuts import render
from webapp.models import Newuser
from django.contrib import messages
import requests
import os
from .services import get_droplets
from django.views.generic import TemplateView

def home(request):
    return render(request, 'home.html')

def login(request):
    if request.method=='POST':
        try:
            userdetails=Newuser.objects.get(email=request.POST['email'], password=request.POST['password'])
            print("username",userdetails)
            request.session['Email']=userdetails.email
            return render(request, "home.html")
        except Newuser.DoesNotExist as e:
            messages.success(request, 'Invalid Email / Password ')
    return render(request, "login.html")

def registration(request):
    if request.method=='POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        
        Newuser(username=username, email=email, password=password).save()
        messages.success(request, 'The New user'+request.POST['username']+'is saved successfully')
        return render(request, 'registration.html')
    else:
        return render(request, 'registration.html')

def logout_view(request):
    logout(request)
    return redirect('/')



   
def GetDetails(requests):
    template_name = 'add-ticket.html'
    context = {
            'droplets' : get_droplets(),
        }
    return context
    print("Hello getdetails122222")
    return render(request, 'add-ticket.html')
    # url = 'https://desk.zoho.in/api/v1/tickets'
    # r = requests.get(url, headers={'Authorization':'Bearer %s' % '9446933330c7f886fbdf16782906a9e0'})
    # droplets = r.json()
    # droplet_list = []print("this is service")
    # for i in range(len(droplets['droplets'])):
    #     droplet_list.append(droplets['droplets'][i])
    # return droplet_list


