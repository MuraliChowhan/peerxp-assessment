from django.urls import path
from .import  views

urlpatterns=[
     path('home/',views.home, name='home'),
     path('login/',views.login, name='login'),
     path('registration/',views.registration, name='registration'),
     path('GetDetails/',views.GetDetails, name='GetDetails'),
]

# path('', GetDetails.as_view(template_name='add-ticket.html'), name='DGetdetails View'),