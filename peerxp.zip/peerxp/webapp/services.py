import os
import requests

def get_droplets():
    print("this is service")
    url = 'https://desk.zoho.in/api/v1/tickets'
    r = requests.get(url, headers={'Authorization':'Bearer %s' % os.getenv('9446933330c7f886fbdf16782906a9e0')})
    droplets = r.json()
    droplet_list = []
    for i in range(len(droplets['droplets'])):
        droplet_list.append(droplets['droplets'][i])
    return droplet_list
    print("this is service end")